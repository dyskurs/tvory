---
layout: page
title: About
---

Holo Alfa is a minimalist, mobile first Jekyll theme with focus on readability and content. Created for free and for fun by Stijn. Get the latest version at the [Github repository](https://github.com/stijnvc/holo-alfa).

---

Holo Alfa is open source, [MIT license](http://opensource.org/licenses/MIT).
