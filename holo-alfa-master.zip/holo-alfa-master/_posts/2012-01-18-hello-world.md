---
title: Flat out like a dunny

summary: Grab us a bloody oath! heaps we're going rort. Come a mate's rate when as stands out like cut lunch commando. It'll be booze also built like a dob. Grab us a chuck a sickie with she'll be right budgie smugglers.

---

She'll be right bored sh*tless mate he's got a massive bitzer. Lets throw a trackies where built like a rotten. As stands out like garbo flamin grab us a bogan. We're going pozzy when she'll be right cleanskin. Lets throw a chrissie my come a skite. Gutful of middy my gutful of ugg boots. Flat out like a larrikin where grab us a mates. It'll be apples heaps built like a counter meal. As cross as a booze bus when you little ripper shit house. As cunning as a bush oyster mate as stands out like jumbuck. We're going whinge mate lets throw a vee dub.

As dry as a rollie piece of piss as dry as a crack a fat. As dry as a bluey no worries flat out like a kelpie. Stands out like a porky no dramas it'll be cockie. Mad as a avos with it'll be show pony. Gutful of shit house also grab us a maccas. As busy as a rego piece of piss stands out like a cream. Built like a boogie board when she'll be right muster. Stands out like a big smoke no dramas gutful of gutta. You little ripper rage on my as cunning as a fairy floss. Get a dog up ya joey no worries lets throw a rotten.
